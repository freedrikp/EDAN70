package decision_trees;

public interface DecisionNode {

	public String print(int level);

	public boolean isTerminal();
}
